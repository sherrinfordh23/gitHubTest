<?php
$host="127.0.0.1";
$dbName="dbstudent";
$user="root";
$pass="";