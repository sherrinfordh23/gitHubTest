<?php

$cpt=0;

$list[$cpt++]=20;
$list[$cpt++]=30;

foreach($list as $one)
    echo $one."<br/>";
